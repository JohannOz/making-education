# SUBAGENT_REGISTRY.md

This document serves as the live register of all active subagents in the Making Education Orchestrator framework. The Orchestrator must consult this file to determine which subagent to invoke for a given user request.

If a new subagent is created, it MUST be added to this table, and the `sync` protocol must be triggered to push the update to GitHub.

| Agent ID | Name | File Path | Purpose | Required Inputs |
| :--- | :--- | :--- | :--- | :--- |
| **01** | Content Localisation | `subagents/Agent_01_ContentLocalisation.md` | Adapts Australian course content to the New Zealand context. | 1. Raw text of the AU course module/document. |
| **02** | B2B Outreach | `subagents/Agent_02_B2BOutreach.md` | Generates personalised cold emails to target ECE centre directors offering pilot access. | 1. Target Name<br>2. Centre Name<br>3. Specific Context (e.g., recent post, philosophy). |
| **03** | Expert Interview Structuring | `subagents/Agent_03_InterviewStructuring.md` | Converts a raw interview transcript into a structured 3-module course outline. | 1. Raw transcript text<br>2. Target audience level (e.g., New Educators). |
| **04** | Course Script Drafting | `subagents/Agent_04_CourseScriptDrafting.md` | Expands an approved course outline into a full audio script ready for production. | 1. Approved outline (from Agent 03)<br>2. Brand voice notes (optional). |
| **05** | Feedback Synthesis | `subagents/Agent_05_FeedbackSynthesis.md` | Processes raw pilot feedback into a one-page actionable product brief. | 1. Raw text from surveys, emails, and LMS notes (minimum 10 responses). |
| **06** | NZ Compliance Tracker | `subagents/Agent_06_NZComplianceTracker.md` | Monitors cumulative NZD revenue against the $60,000 GST registration threshold. | 1. Monthly revenue figures (in AUD or NZD). |

## Registry Maintenance Rules
1. **File Paths:** Ensure the file path listed in the registry exactly matches the `.md` file in the `subagents/` directory.
2. **Versioning:** If a subagent is significantly updated, the filename should reflect the version (e.g., `Agent_01_ContentLocalisation_v2.md`) and this registry must be updated to match.
3. **Required Inputs:** The Orchestrator MUST NOT invoke a subagent until the user has provided all inputs listed in the `Required Inputs` column.
