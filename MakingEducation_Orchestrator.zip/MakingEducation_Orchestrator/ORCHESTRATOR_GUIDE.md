# Orchestrator Setup & Operations Guide

This guide explains how to set up and use the Making Education Orchestrator within Claude Desktop. The Orchestrator uses a distributed architecture: the central "brain" and all subagents live in a GitHub repository, and each team member connects their local Claude Desktop to that repository.

## 1. Initial Setup (For Each Team Member)

To use the Orchestrator, you must clone the central repository to your local machine and point Claude Desktop to it.

1. **Clone the Repository:**
   Open your terminal and clone the Making Education Orchestrator repository to a dedicated folder on your machine:
   ```bash
   git clone https://github.com/YourOrg/MakingEducation_Orchestrator.git
   ```

2. **Configure Claude Desktop:**
   Open Claude Desktop. Go to Settings > Developer and enable local file access. Point Claude to the folder where you just cloned the repository.

3. **Start a Session:**
   In a new Claude chat, type:
   *"Load Orchestrator from CLAUDE.md"*
   Claude will read the `CLAUDE.md`, `SKILLS.md`, and `SUBAGENT_REGISTRY.md` files and adopt the Orchestrator persona.

## 2. Using the Orchestrator

Do not ask the Orchestrator to do work directly. Ask it to manage tasks using its subagents.

**Example Request:**
> *"I need to write an outreach email to Sarah, the Director of Kiwi Kids ECE. I noticed on LinkedIn they just opened a new outdoor play area."*

The Orchestrator will:
1. Check the `SUBAGENT_REGISTRY.md`.
2. Identify that Agent 02 (B2B Outreach) is the correct tool.
3. Check if you provided the required inputs (Target Name, Centre Name, Context).
4. Invoke Agent 02 internally, generate the email, and present it to you.

## 3. The Sync Protocol (Pushing Updates to the Team)

Because the team uses multiple Claude Desktop instances, changes made locally must be synced to GitHub so everyone else gets them.

**When to Sync:**
- If you ask the Orchestrator to create a new subagent.
- If you ask the Orchestrator to permanently update an existing subagent's prompt.

**How to Sync:**
Simply tell the Orchestrator:
> *"sync"*

The Orchestrator will automatically run the Git commands (`git add`, `git commit`, `git push`) to push the updates to the central GitHub repository.

**Receiving Updates:**
When you start work for the day, you should pull the latest changes from the team:
Open your terminal in the repository folder and run:
```bash
git pull origin main
```
*(Alternatively, you can ask the Orchestrator to run `git pull` for you).*

## 4. Building New Subagents

The Orchestrator can build new tools for the team. If you have a repetitive task, ask the Orchestrator to build a subagent for it.

**Example Request:**
> *"I want to build a new subagent that takes a blog post and turns it into 3 LinkedIn posts. The inputs will be the blog text and the target country."*

The Orchestrator will draft the new prompt file, save it in the `subagents/` folder, update the `SUBAGENT_REGISTRY.md`, and then you simply say *"sync"* to share it with the rest of the team.
