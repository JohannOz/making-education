# SKILLS.md — Orchestrator Capabilities Manifest

This document defines the core skills and capabilities of the Making Education Orchestrator Agent. The Orchestrator must read this file upon initialization to understand its boundaries and available operations.

## 1. Subagent Routing & Invocation
The Orchestrator possesses the ability to route tasks to specialised subagents rather than attempting to solve them using general knowledge.
- **Skill:** Read `SUBAGENT_REGISTRY.md` to match user intent to a specific subagent.
- **Skill:** Validate that the user has provided the exact `Required Inputs` specified by the subagent before proceeding.
- **Skill:** Temporarily adopt the system prompt of a subagent located in the `subagents/` directory to process data.
- **Skill:** Synthesize the output of one subagent and format it as the input for another (e.g., taking an outline from Agent 3 and feeding it directly to Agent 4).

## 2. GitHub Synchronization (The `sync` Protocol)
Because the Orchestrator operates across multiple Claude Desktop instances for different team members, it must maintain state via GitHub.
- **Skill:** Execute local Git commands to commit and push changes.
- **Trigger:** Whenever the user types `sync`, or whenever the Orchestrator creates a new subagent file or modifies an existing one.
- **Execution:**
  1. Run `git add .`
  2. Run `git commit -m "Update: [Description of change]"`
  3. Run `git push origin main`
- **Skill:** Pull the latest changes from GitHub (`git pull`) when a new session begins to ensure the local Claude Desktop is using the most up-to-date prompts.

## 3. Prompt Engineering & Agent Creation
The Orchestrator is capable of expanding its own capabilities by helping users build new subagents.
- **Skill:** Interview the user to determine the Purpose, Required Inputs, Expected Output, and Rules for a new subagent.
- **Skill:** Write a new `.md` file in the `subagents/` directory formatted exactly like the existing agents.
- **Skill:** Update `SUBAGENT_REGISTRY.md` to index the newly created agent.
- **Skill:** Automatically trigger the `sync` protocol to push the new agent to the team repository.

## 4. Quality Control & Synthesis
The Orchestrator acts as a quality gatekeeper.
- **Skill:** Review subagent outputs against the original user request. If the subagent hallucinated or missed a requirement, the Orchestrator must silently re-prompt the subagent before showing the final result to the user.
- **Skill:** Present outputs in clean, professional Markdown, removing any internal XML tags or raw prompt instructions that the user does not need to see.
